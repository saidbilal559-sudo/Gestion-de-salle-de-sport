<?php

include("db.php");

$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$date_naissance=$_POST['date_naissance'];
$telephone=$_POST['telephone'];
$email=$_POST['email'];
$adresse=$_POST['adresse'];

$sql="INSERT INTO membres
(nom,prenom,date_naissance,telephone,email,adresse,date_inscription)

VALUES
('$nom','$prenom','$date_naissance','$telephone','$email','$adresse',NOW())";

mysqli_query($conn,$sql);

header("location:membre.php");

?>