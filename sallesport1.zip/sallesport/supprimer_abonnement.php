<?php
include("db.php");

$id=$_GET['id'];

mysqli_query($conn,"DELETE FROM abonnements WHERE id_abonnement=$id");

header("location:abonnements.php");
?>