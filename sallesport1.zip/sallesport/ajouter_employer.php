<?php

include("db.php");

$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$telephone=$_POST['telephone'];
$email=$_POST['email'];

mysqli_query($conn,"INSERT INTO employes(nom,prenom,telephone,email)
VALUES('$nom','$prenom','$telephone','$email')");

header("location:employes.php");

?>