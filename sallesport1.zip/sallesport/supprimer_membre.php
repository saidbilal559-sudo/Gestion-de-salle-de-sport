<?php

include("db.php");

$id=$_GET['id'];

mysqli_query($conn,"DELETE FROM membres WHERE id_membre=$id");

header("location:membre.php");

?>