<?php
// Inclusion de la connexion à la base de données
include("db.php");

// Vérifier que l'ID est bien présent dans l'URL et est un nombre
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id_paiement = (int) $_GET['id'];

    // Requête de suppression
    $sql = "DELETE FROM paiements WHERE id_paiement = $id_paiement";

    if (mysqli_query($conn, $sql)) {
        // Redirection vers la page principale
        header("Location: paiements.php");
        exit();
    } else {
        echo "Erreur lors de la suppression : " . mysqli_error($conn);
    }
} else {
    // Si l'ID n'est pas valide, on redirige
    header("Location: paiements.php");
    exit();
}
?>