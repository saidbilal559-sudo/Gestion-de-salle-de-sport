<?php

include("db.php");

$id=$_GET['id'];

mysqli_query($conn,"DELETE FROM coach WHERE id_coach=$id");

header("location:coach.php");

?>