<?php

include("db.php");

$nom=$_POST['nom_abonnement'];
$prix=$_POST['prix'];
$duree=$_POST['duree'];

mysqli_query($conn,"INSERT INTO abonnements(nom_abonnement,prix,duree)
VALUES('$nom','$prix','$duree')");

header("location:abonnements.php");

?>