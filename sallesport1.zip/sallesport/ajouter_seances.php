<?php
// Inclusion de la connexion à la base de données
include("db.php");

// Vérification que le formulaire a bien été soumis en POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Récupération et sécurisation des données
    $type_seance = mysqli_real_escape_string($conn, $_POST['type_seance']);
    $date_seance = mysqli_real_escape_string($conn, $_POST['date_seance']);
    $heure_debut = mysqli_real_escape_string($conn, $_POST['heure_debut']);
    $heure_fin   = mysqli_real_escape_string($conn, $_POST['heure_fin']);
    $id_coach    = (int) $_POST['id_coach']; // conversion en entier pour sécurité

    // Validation basique : vérifier que les champs obligatoires ne sont pas vides
    if (empty($type_seance) || empty($date_seance) || empty($heure_debut) || empty($heure_fin) || empty($id_coach)) {
        die("Tous les champs sont requis.");
    }

    // Construction de la requête d'insertion
    $sql = "INSERT INTO seances (type_seance, date_seance, heure_debut, heure_fin, id_coach)
            VALUES ('$type_seance', '$date_seance', '$heure_debut', '$heure_fin', $id_coach)";

    // Exécution et vérification
    if (mysqli_query($conn, $sql)) {
        // Redirection vers la page principale (à modifier selon votre nom de fichier)
        header("Location: seances.php");
        exit();
    } else {
        // En cas d'erreur SQL, on affiche le message (à améliorer en production)
        echo "Erreur lors de l'ajout : " . mysqli_error($conn);
    }

} else {
    // Si quelqu'un accède directement à ce fichier sans passer par le formulaire
    header("Location:seances.php");
    exit();
}
?>