<?php

include("db.php");

$id=$_GET['id'];

mysqli_query($conn,"DELETE FROM seances WHERE id_seance=$id");

header("location:seances.php");

?>