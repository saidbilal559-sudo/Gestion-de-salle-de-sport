<?php

$host = "localhost";
$user = "root";
$password = "";
$db = "sallesport";

$conn = mysqli_connect($host,$user,$password,$db);

if(!$conn){
die("Erreur de connexion à la base de données");
}

?>