<?php
session_start();
if(!isset($_SESSION['user'])){
header("location:login.php");
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Dashboard - Gym</title>
<style>/* =========================
   RESET + BASE
========================= */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', sans-serif;
    background: radial-gradient(circle at top, #142850, #0A0F1C);
    color: #EAF4FF;
    height: 100vh;
    display: flex;
}

/* =========================
   SIDEBAR AUTO (1er bloc gauche)
========================= */
body > div:first-child {
    width: 260px;
    background: linear-gradient(180deg, #0B1E3C, #020617);
    padding: 30px 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;

    border-right: 1px solid rgba(255,255,255,0.05);
}

/* TITRE (GYM PANEL) */
body > div:first-child h2 {
    color: #6CABDD;
    text-align: center;
    margin-bottom: 40px;
    letter-spacing: 2px;
}

/* MENU */
body > div:first-child a {
    display: block;
    color: #cbd5e1;
    text-decoration: none;
    padding: 12px 15px;
    margin: 10px 0;
    border-radius: 10px;
    transition: all 0.3s ease;
}

/* HOVER MENU */
body > div:first-child a:hover {
    background: linear-gradient(135deg, #6CABDD, #3fa3ff);
    color: #0A0F1C;
    transform: translateX(6px);
    box-shadow: 0 5px 15px rgba(108,171,221,0.3);
}

/* BOUTON DECONNEXION */
body > div:first-child a:last-child {
    border: 1px solid #6CABDD;
    text-align: center;
    margin-top: 20px;
}

body > div:first-child a:last-child:hover {
    background: #6CABDD;
    color: #0A0F1C;
}

/* =========================
   CONTENU PRINCIPAL
========================= */
body > div:last-child {
    flex: 1;
    padding: 50px;
}

/* TEXTE INTRO */
body > div:last-child p {
    color: #94a3b8;
    margin-bottom: 10px;
}

/* TITRE PRINCIPAL */
body > div:last-child h1 {
    font-size: 42px;
    color: #ffffff;
    font-weight: bold;
}

/* LIGNE DESIGN */
body > div:last-child h1::after {
    content: "";
    display: block;
    width: 90px;
    height: 5px;
    background: linear-gradient(90deg, #6CABDD, #3fa3ff);
    margin-top: 12px;
    border-radius: 5px;
}

/* =========================
   CARDS (si ajout futur)
========================= */
.card {
    background: rgba(255,255,255,0.05);
    padding: 25px;
    margin-top: 20px;
    border-radius: 15px;
    backdrop-filter: blur(10px);

    border: 1px solid rgba(255,255,255,0.05);

    box-shadow: 0 10px 30px rgba(0,0,0,0.4);
    transition: 0.3s;
}

.card:hover {
    transform: translateY(-5px);
}

/* =========================
   SCROLLBAR (classe pro)
========================= */
::-webkit-scrollbar {
    width: 8px;
}

::-webkit-scrollbar-track {
    background: #0A0F1C;
}

::-webkit-scrollbar-thumb {
    background: #6CABDD;
    border-radius: 10px;
}

/* =========================
   RESPONSIVE
========================= */
@media (max-width: 768px) {
    body {
        flex-direction: column;
    }

    body > div:first-child {
        width: 100%;
        flex-direction: row;
        overflow-x: auto;
    }

    body > div:last-child {
        padding: 20px;
    }
}</style>

</head>

<body>

<div class="container">

<div class="sidebar">

<h2>GYM PANEL</h2>

<ul>

<li><a href="membre.php">Gestion Membres</a></li>

<li><a href="coach.php">Gestion Coach</a></li>

<li><a href="seances.php">Gestion Seances</a></li>

<li><a href="paiements.php">Gestion Paiements</a></li>

<li><a href="employer.php">Gestion des Employés</a></li>

<li><a href="abonnements.php">Gestion des Abonnements</a></li>

<li><a href="logout.php" class="logout">Déconnexion</a></li>

</ul>

</div>


<div class="content">
<p>Bienvenue dans le système de :</p>
<h1>Gestion Salle de Sport</h1>



</div>

</div>

</body>
</html>