<?php

include("db.php");

$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$specialite=$_POST['specialite'];
$telephone=$_POST['telephone'];
$email=$_POST['email'];

mysqli_query($conn,"INSERT INTO coach
(nom,prenom,specialite,telephone,email)
VALUES
('$nom','$prenom','$specialite','$telephone','$email')");

header("location:coach.php");

?>