<?php
// Inclusion de la connexion à la base de données
include("db.php");

// Vérification que le formulaire a été soumis en POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Récupération et sécurisation des données
    $id_membre     = (int) $_POST['id_membre']; // conversion en entier
    $type_seance   = mysqli_real_escape_string($conn, $_POST['type_seance']);
    $date_paiement = mysqli_real_escape_string($conn, $_POST['date_paiement']);
    $mode_paiement = mysqli_real_escape_string($conn, $_POST['mode_paiement']);

    // Validation simple : vérifier que tous les champs sont remplis
    if (empty($id_membre) || empty($type_seance) || empty($date_paiement) || empty($mode_paiement)) {
        die("Tous les champs sont requis.");
    }

    // Requête d'insertion
    $sql = "INSERT INTO paiements (id_membre, type_seance, date_paiement, mode_paiement)
            VALUES ($id_membre, '$type_seance', '$date_paiement', '$mode_paiement')";

    if (mysqli_query($conn, $sql)) {
        // Redirection vers la page principale (remplacez "gestion_paiements.php" par le nom de votre fichier principal)
        header("Location: paiements.php");
        exit();
    } else {
        // En cas d'erreur SQL
        echo "Erreur lors de l'ajout : " . mysqli_error($conn);
    }

} else {
    // Si quelqu'un accède directement sans POST, on redirige
    header("Location: paiements.php");
    exit();
}
?>