<?php
include("db.php");
?>

<!DOCTYPE html>
<html>
<head>
<title>Gestion Employés</title>
<link rel="stylesheet" href="style.css">
</head>
<style>/* =======================
   RESET
======================= */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* =======================
   BODY
======================= */
body {
    font-family: 'Segoe UI', Tahoma, sans-serif;
    background: linear-gradient(135deg, #0A1F44, #A50044);
    padding: 30px;
    color: #ffffff;
}

/* =======================
   TITRE PRINCIPAL
======================= */
h1 {
    text-align: center;
    margin-bottom: 30px;
    font-size: 32px;
    font-weight: bold;
    letter-spacing: 1px;
    color: #FDB913;
    text-shadow: 0 2px 10px rgba(0,0,0,0.5);
}

/* =======================
   SOUS TITRES
======================= */
h2 {
    margin: 25px 0 10px;
    color: #FDB913;
    border-left: 6px solid #FDB913;
    padding-left: 10px;
}

/* =======================
   FORMULAIRE
======================= */
form {
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(10px);
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 30px;

    display: flex;
    flex-wrap: wrap;
    gap: 10px;

    border: 1px solid rgba(255,255,255,0.2);
}

/* =======================
   INPUTS
======================= */
input {
    flex: 1;
    min-width: 150px;
    padding: 10px;
    border-radius: 8px;
    border: none;
    outline: none;
    font-size: 14px;

    background: rgba(255,255,255,0.15);
    color: white;
}

/* Placeholder */
input::placeholder {
    color: rgba(255,255,255,0.7);
}

/* Focus */
input:focus {
    border: 1px solid #FDB913;
    box-shadow: 0 0 8px #FDB913;
}

/* =======================
   BOUTON
======================= */
button {
    background: linear-gradient(135deg, #FDB913, #ffcc33);
    color: #0A1F44;
    border: none;
    padding: 10px 18px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
    transition: 0.3s;
}

button:hover {
    transform: translateY(-2px) scale(1.05);
    box-shadow: 0 5px 15px rgba(0,0,0,0.4);
}

/* =======================
   TABLEAU
======================= */
table {
    width: 100%;
    border-collapse: collapse;
    border-radius: 12px;
    overflow: hidden;

    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(8px);

    box-shadow: 0 10px 25px rgba(0,0,0,0.4);
}

/* HEADER TABLE */
th {
    background: linear-gradient(135deg, #A50044, #0A1F44);
    color: #FDB913;
    padding: 14px;
    text-transform: uppercase;
    font-size: 14px;
}

/* CELLS */
td {
    padding: 12px;
    text-align: center;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

/* HOVER ROW */
tr:hover {
    background: rgba(253, 185, 19, 0.1);
}

/* =======================
   ACTIONS (si ajoutées plus tard)
======================= */
.action-btn {
    padding: 6px 10px;
    border-radius: 6px;
    font-size: 12px;
    margin: 2px;
}

/* EDIT */
.edit {
    background: #FDB913;
    color: #0A1F44;
}

/* DELETE */
.delete {
    background: #A50044;
    color: white;
}

/* =======================
   EFFET CARD
======================= */
form, table {
    transition: 0.3s;
}

form:hover, table:hover {
    transform: translateY(-3px);
}

/* =======================
   RESPONSIVE
======================= */
@media (max-width: 768px) {
    form {
        flex-direction: column;
    }

    input, button {
        width: 100%;
    }

    table {
        font-size: 12px;
    }
}</style>
<body>

<div class="main">

<h1>Gestion des Employés</h1>

<div class="form-box">
<h2>Ajouter Employé</h2>

<form action="ajouter_employe.php" method="POST">

<input type="text" name="nom" placeholder="Nom" required>
<input type="text" name="prenom" placeholder="Prénom" required>
<input type="text" name="telephone" placeholder="Téléphone">
<input type="email" name="email" placeholder="Email">

<button type="submit">Ajouter</button>

</form>
</div>

<div class="table-box">

<h2>Liste des Employés</h2>

<table>

<tr>
<th>ID</th>
<th>Nom</th>
<th>Prénom</th>
<th>Téléphone</th>
<th>Email</th>
<th>Action</th>
</tr>

<?php

$result=mysqli_query($conn,"SELECT * FROM employes");

while($row=mysqli_fetch_assoc($result)){

echo "<tr>";

echo "<td>".$row['id_employe']."</td>";
echo "<td>".$row['nom']."</td>";
echo "<td>".$row['prenom']."</td>";
echo "<td>".$row['telephone']."</td>";
echo "<td>".$row['email']."</td>";

echo "<td>
<a class='delete' href='supprimer_employe.php?id=".$row['id_employe']."'>Supprimer</a>
</td>";

echo "</tr>";
}
?>

</table>

</div>

</div>

</body>
</html>