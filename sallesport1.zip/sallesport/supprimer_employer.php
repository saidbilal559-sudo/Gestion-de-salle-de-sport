<?php
include("db.php");

$id=$_GET['id'];

mysqli_query($conn,"DELETE FROM employes WHERE id_employe=$id");

header("location:employes.php");
?>