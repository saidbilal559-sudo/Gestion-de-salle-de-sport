<!DOCTYPE html>
<html>
<head>

<title>Connexion - Salle de Sport</title>

<style>

body{
font-family: Arial;
background: linear-gradient(120deg,#2980b9,#6dd5fa);
height:100vh;
display:flex;
justify-content:center;
align-items:center;
}

.login-box{
background:white;
padding:40px;
border-radius:10px;
width:320px;
text-align:center;
box-shadow:0px 5px 15px rgba(0,0,0,0.3);
}

h2{
margin-bottom:20px;
}

input{
width:100%;
padding:10px;
margin:10px 0;
border-radius:5px;
border:1px solid #ccc;
}

button{
background:#2980b9;
color:white;
border:none;
padding:10px;
width:100%;
border-radius:5px;
cursor:pointer;
font-size:16px;
}

button:hover{
background:#1f6391;
}

</style>

</head>

<body>

<div class="login-box">

<h2>Connexion Admin</h2>

<form action="verification.php" method="POST">

<input type="text" name="username" placeholder="Nom utilisateur" required>

<input type="password" name="password" placeholder="Mot de passe" required>

<button type="submit">Se connecter</button>

</form>

</div>

</body>
</html>